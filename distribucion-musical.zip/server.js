const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

mongoose.connect('mongodb://localhost:27017/musica', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const Song = mongoose.model('Song', {
  title: String,
  artist: String,
  platforms: [String],
  coverUrl: String,
  audioUrl: String,
});

const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: (_, file, cb) => cb(null, Date.now() + '-' + file.originalname),
});

const upload = multer({ storage });

app.post('/upload', upload.fields([
  { name: 'coverImage', maxCount: 1 },
  { name: 'audioFile', maxCount: 1 },
]), async (req, res) => {
  const { title, artist, platforms } = req.body;
  const coverUrl = `/uploads/${req.files.coverImage[0].filename}`;
  const audioUrl = `/uploads/${req.files.audioFile[0].filename}`;

  const song = new Song({ title, artist, platforms: JSON.parse(platforms), coverUrl, audioUrl });
  await song.save();

  res.json({ message: 'Canción subida correctamente', song });
});

app.listen(4000, () => console.log('Servidor en http://localhost:4000'));
